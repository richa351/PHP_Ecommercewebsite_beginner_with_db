<?php
$con = mysqli_connect("localhost", "root", "", "ecommercewebsite");

if (!$con) {
   die(mysqli_connect_error());

}

?>