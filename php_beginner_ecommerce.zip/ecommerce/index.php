<!<!DOCTYPE html>

   <html>

   <head>

      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>ECOMMERCE WEBSITE</title>
      <!--BOOTSTRAP CSS-->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
         integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
   </head>

   <body>
      <?php include './partials/header.php' ?>
      <?php include './partials/connect.php' ?>
      <h1 class="text-center text-primary m-3">Welcome to our Store</h1>
      <h1 class="text-center text-success mb-4">Shop By Category</h1>

      <!--  CARD CONTAINER-->
      <div class="container">
         <div class="row">

            <?php
            $sql = "SELECT * FROM clothes";
            $result = mysqli_query($con, $sql);
            if ($result) {
               while ($row = mysqli_fetch_assoc($result)) {
                  $category_id = $row['category_id'];
                  $category_name = $row['category_name'];
                  $category_desc = $row['category_desc'];
                  $category_price = $row['category_price'];
                  $category_image = $row['category_image'];

                  echo ' <div class="col-md-4 col-sm-6-col-xm-12 mb=5 ">
                  <div class="card mb-6" style="height:300px;margin-bottom: 35rem; object-fit:contain">
                     <img src=' . $category_image . ' class="card-img-top" alt="image1.png">
                     <div class="card-body">
                        <h5 class="card-title">' . $category_name . '</h5>
                        <p class="card-text">' . substr($category_desc, 0, 55) . '...</p>
                        <p style="color:red;font-size:20px">' . $category_price . '/-</p>
                        <a href="details.php?details_id=' . $category_id . '" class="btn btn-primary">Shop Now</a>
                     </div>
                  </div>
   
               </div>';
               }
            }

            ?>


         </div>
      </div>
   </body>

   </html>