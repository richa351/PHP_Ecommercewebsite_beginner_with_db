<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Ecommerce Website</title>
   <!--                  BOOTSTRAP LINK           -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
</head>

<body>
   <?php include './partials/header.php' ?>
   <?php include './partials/connect.php' ?>
   <?php
   $id = $_GET['details_id'];
   //SQL QUERY TO FETCH PARTICULAR ID DATA
   $sql = "SELECT * FROM clothes where  category_id='$id'";
   $result = mysqli_query($con, $sql);
   $row = mysqli_fetch_assoc($result);
   $category_id = $row['category_id'];
   $category_name = $row['category_name'];
   $category_desc = $row['category_desc'];
   $category_price = $row['category_price'];
   $category_image = $row['category_image'];
   ?>
   <div class="jumbotron">
      <div class="container" style="background-color: #f5f5f5;">
         <h1 class="display-4 text-center text-primary">
            <?php echo $category_name ?>
         </h1>
         <h4> Description</h4>
         <p class="lead"></p>
         <?php echo $category_desc ?>
         </p>
         <button class="btn btn-primary btn-lg mt-3">
            <a class="btn btn-primary btn-lg " href="index.php" role="button">Contine Shopping</a>
         </button>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-lg-6 col-sm-12">
            <img src="<?php echo $category_image ?>" class='img-fluid' style="max-width:100%;height:80%;" alt="">
         </div>
         <div class="col-lg-6 col-sm-12">
            <h2 class="text-center text-danger mt-5">
               <?php echo $category_name ?>
            </h2>
            <p class=" text-justify mt-3">
               <?php echo $category_desc ?>
            </p>
            <p><strong>Price:</strong>
               <?php echo $category_price ?>/-
            </p>
            <button class="btn btn-success btn-lg ">Add To Cart
            </button>
         </div>
      </div>
   </div>
</body>

</html>